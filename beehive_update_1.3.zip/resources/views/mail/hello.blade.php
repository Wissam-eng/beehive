<h1>your otp is {{ $otp }}</h1>
